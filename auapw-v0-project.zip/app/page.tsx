"use client"

import AuapwApp from "@/components/auapw-complete"

export default function Home() {
  return <AuapwApp />
}
