# AUAPW.ORG — All Used Auto Parts Warehouse

> Your Trusted Partner for Automotive Services & Solutions

Premium used auto parts e-commerce platform connecting buyers with 2,000+ verified salvage yards nationwide.

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Deploy to v0.app

1. Go to [v0.app](https://v0.app)
2. Click **+** → **Upload from computer**
3. Upload this project as a zip
4. Click **Publish** to deploy

## Tech Stack

- **Frontend:** Next.js 15 + React 19 + TypeScript
- **Styling:** Tailwind CSS + Custom Chrome Industrial Theme
- **Icons:** Lucide React
- **Deployment:** Vercel (via v0.app)
- **Commerce Backend:** Medusa.js (see ARCHITECTURE.md)
- **Search:** Algolia / Typesense (for 2.2M products)

## Project Structure

```
auapw-v0-project/
├── app/
│   ├── layout.tsx          # Root layout with SEO + structured data
│   ├── page.tsx            # Homepage entry point
│   └── globals.css         # Tailwind + font imports
├── components/
│   └── auapw-complete.tsx  # Full AUAPW application component
├── middleware.ts            # Brand subdomain routing
├── next.config.js          # Rewrites, headers, image config
├── tailwind.config.ts      # Theme tokens
├── package.json
├── tsconfig.json
├── ARCHITECTURE.md         # Full scaling strategy for 2.2M products
└── README.md
```

## Brand Subdomains

Configure wildcard DNS (`*.auapw.org → cname.vercel-dns.com`) to enable:
- ford.auapw.org → Ford parts
- toyota.auapw.org → Toyota parts
- etc. for all 48+ brands

## Contact

- **Phone:** (888) 818-5001
- **Email:** info@auapw.org
- **Address:** 107 Myrtle Ave, Woodbine, NJ 08270
