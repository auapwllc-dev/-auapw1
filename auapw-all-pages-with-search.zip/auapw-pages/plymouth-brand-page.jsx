import React, { useState } from "react";


const PHONE = "(888) 818-5001";
const EMAIL = "auapworld@gmail.com";
const ADDRESS = "107 Myrtle Ave, Woodbine, NJ 08270";

const T = {
  bg:"#07090f", card:"rgba(19,22,30,0.72)", bd:"rgba(232,232,232,0.12)",
  bdd:"rgba(255,255,255,0.06)", fg:"#f5f5f5", muted:"#9ca3af", dim:"#6b7280",
  dimmer:"#4b5563",
  mono:"'DM Mono','Courier New',monospace",
  serif:"'Syne','Georgia',sans-serif",
  sans:"'DM Sans',system-ui,sans-serif",
};

const LAYOUT_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800;900&family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;500;600;700;900&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  .auapw{background:#07090f;min-height:100vh;color:#f5f5f5;overflow-x:hidden;font-family:'DM Sans',system-ui,sans-serif}
  button,input,select,textarea{font-family:inherit}
  @keyframes scroll-ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
  @keyframes chrome-sweep{0%{background-position:200% center}100%{background-position:-200% center}}
  @keyframes ghost-scan{0%{transform:translateX(-120%) skewX(-18deg);opacity:0}10%{opacity:1}90%{opacity:1}100%{transform:translateX(420%) skewX(-18deg);opacity:0}}
  @keyframes led-pulse{0%,100%{border-color:rgba(255,255,255,0.65);box-shadow:0 0 8px rgba(255,255,255,0.1)}50%{border-color:rgba(255,255,255,0.18);box-shadow:0 0 2px rgba(255,255,255,0.02)}}
  @keyframes pulse-dot{0%,100%{opacity:1;box-shadow:0 0 8px #fff,0 0 20px rgba(255,255,255,0.5)}50%{opacity:0.4;box-shadow:0 0 3px rgba(255,255,255,0.3)}}
  .auapw-emboss{font-family:'DM Mono','Courier New',monospace;font-weight:900;letter-spacing:0.04em;line-height:1;background:linear-gradient(135deg,#ffffff 0%,#d8dce8 15%,#ffffff 30%,#8890a8 45%,#d0d8ee 60%,#ffffff 75%,#b0b8cc 90%,#e8ecf8 100%);background-size:250% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;animation:chrome-sweep 5s linear infinite;}
  .sub-emboss{font-family:'DM Mono','Courier New',monospace;font-weight:700;letter-spacing:0.22em;text-transform:uppercase;background:linear-gradient(90deg,#606880 0%,#9098b0 20%,#d0d8ee 38%,#ffffff 50%,#d0d8ee 62%,#9098b0 80%,#606880 100%);background-size:300% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;filter:drop-shadow(0 1px 0 rgba(0,0,0,0.7)) drop-shadow(0 -0.5px 0 rgba(255,255,255,0.25));animation:chrome-sweep 6s linear infinite;}
  .tagline-silver{font-family:'DM Mono','Courier New',monospace;font-weight:700;text-transform:uppercase;letter-spacing:0.12em;color:rgba(148,156,178,0.55);}
  .diamond-led{width:7px;height:7px;background:linear-gradient(135deg,#fff 0%,#c8d0e8 40%,#8898b8 80%);transform:rotate(45deg);flex-shrink:0;box-shadow:0 0 6px rgba(255,255,255,0.7),0 0 12px rgba(200,215,240,0.4)}
  .diamond-led-sm{width:5px;height:5px;background:linear-gradient(135deg,#fff 0%,#c8d0e8 40%,#8898b8 80%);transform:rotate(45deg);flex-shrink:0;box-shadow:0 0 4px rgba(255,255,255,0.6),0 0 8px rgba(200,215,240,0.3)}
  .btn-led{display:inline-flex;align-items:center;gap:7px;padding:10px 20px;font-family:'DM Mono','Courier New',monospace;font-weight:700;font-size:10px;letter-spacing:0.16em;text-transform:uppercase;color:#f5f5f5;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.2);border-radius:3px;cursor:pointer;transition:all 0.18s;position:relative;overflow:hidden;text-decoration:none}
  .btn-led:hover{background:rgba(255,255,255,0.12);border-color:rgba(255,255,255,0.42);color:#fff;box-shadow:0 0 14px rgba(255,255,255,0.1)}
  .fc-item{display:flex;align-items:flex-start;gap:10px;transition:opacity 0.18s;text-decoration:none}
  .fc-item:hover{opacity:0.8}
  .fc-icon{width:22px;height:22px;border-radius:3px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;font-size:11px}
  .fc-text{font-size:11px;color:#9ca3af;line-height:1.55}
  .fsec{font-size:9px;font-weight:700;letter-spacing:0.22em;text-transform:uppercase;color:rgba(232,232,232,0.55);font-family:'DM Mono',monospace}
  .wrap{max-width:1120px;margin:0 auto;padding:40px 24px 80px}
  .card{background:rgba(14,17,28,0.9);border:1px solid rgba(255,255,255,0.07);border-radius:8px;padding:24px;margin-bottom:16px}
  .div-line{height:1px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.12),transparent);margin:32px 0}
  p{font-size:15px;color:rgba(165,180,208,.85);line-height:1.8;margin-bottom:14px}
  .fqq{font-weight:700;color:#dde6f8;font-size:15px}
  .fqa{color:rgba(152,168,196,.85);line-height:1.78;font-size:14px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.05)}
  .chip-tag{padding:5px 12px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:4px;font-family:'DM Mono',monospace;font-size:11px;color:rgba(185,202,230,.75);letter-spacing:.05em}
  ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-track{background:#07090f}::-webkit-scrollbar-thumb{background:#3a3f52;border-radius:2px}
`;

const GEAR_PATH = "M 100.000,24.000 L 100.000,6.000 L 116.784,7.511 L 113.570,25.221 A 76 76 0 0 1 132.975,31.526 L 140.785,15.309 L 155.252,23.952 L 144.672,38.515 A 76 76 0 0 1 159.419,52.615 L 173.492,41.392 L 182.776,55.456 L 166.925,63.986 A 76 76 0 0 1 174.095,83.088 L 191.643,79.083 L 193.905,95.783 L 175.923,96.590 A 76 76 0 0 1 174.095,116.912 L 191.643,120.917 L 186.436,136.944 L 169.884,129.870 A 76 76 0 0 1 159.419,147.385 L 173.492,158.608 L 161.846,170.789 L 150.003,157.233 A 76 76 0 0 1 132.975,168.474 L 140.785,184.691 L 125.007,190.613 L 120.219,173.261 A 76 76 0 0 1 100.000,176.000 L 100.000,194.000 L 83.216,192.489 L 86.430,174.779 A 76 76 0 0 1 67.025,168.474 L 59.215,184.691 L 44.748,176.048 L 55.328,161.485 A 76 76 0 0 1 40.581,147.385 L 26.508,158.608 L 17.224,144.544 L 33.075,136.014 A 76 76 0 0 1 25.905,116.912 L 8.357,120.917 L 6.095,104.217 L 24.077,103.410 A 76 76 0 0 1 25.905,83.088 L 8.357,79.083 L 13.564,63.056 L 30.116,70.130 A 76 76 0 0 1 40.581,52.615 L 26.508,41.392 L 38.154,29.211 L 49.997,42.767 A 76 76 0 0 1 67.025,31.526 L 59.215,15.309 L 74.993,9.387 L 79.781,26.739 A 76 76 0 0 1 100.000,24.000 Z";


// ═══════════════════════════════════════════════════
//  PARTS FINDER WIDGET
// ═══════════════════════════════════════════════════
const PF_CATS = {"Engine & Drivetrain":["Engine (Long Block)","Engine (Short Block)","Engine Assembly","Cylinder Head","Engine Block","Crankshaft","Camshaft","Timing Chain Kit","Timing Belt Kit","Oil Pan","Valve Cover","Intake Manifold","Exhaust Manifold","Turbocharger","Supercharger","Intercooler","EGR Valve","Throttle Body"],"Transmission":["Automatic Transmission","Manual Transmission","CVT Transmission","Transfer Case","Transfer Case Motor","Front Drive Shaft","Rear Drive Shaft","Flywheel / Flex Plate","Torque Converter","Transmission Control Module"],"Axles & Differential":["Front Axle Assembly","Rear Axle Assembly","Front Differential","Rear Differential","CV Axle / Half Shaft","Axle Shaft","Differential Carrier","Hub Assembly / Bearing","Locking Hub"],"Suspension & Steering":["Front Strut Assembly","Rear Shock / Strut","Coil Spring","Leaf Spring","Air Spring / Bag","Air Suspension Compressor","Lower Control Arm","Upper Control Arm","Ball Joint","Tie Rod End","Sway Bar / End Link","Power Steering Pump","Steering Rack / Gear","Steering Column","Spindle / Knuckle"],"Brakes":["Brake Caliper","Brake Rotor","Brake Drum","ABS Module / Pump","Brake Master Cylinder","Brake Booster","Wheel Speed Sensor","Proportioning Valve"],"Cooling & Heating":["Radiator","Radiator Fan / Motor","Water Pump","Thermostat Housing","Coolant Reservoir","Heater Core","Blower Motor","HVAC Temp Control","AC Compressor","AC Condenser","AC Evaporator","Expansion Valve"],"Electrical":["Alternator","Starter Motor","Battery","Fuse Box (Engine)","Fuse Box (Interior)","ECM / PCM (Engine Computer)","BCM (Body Computer)","Ignition Switch","Wiper Motor (Front)","Wiper Motor (Rear)","Window Regulator Motor","Door Lock Actuator","Power Seat Motor","ABS Control Module"],"Fuel System":["Fuel Pump (In-Tank)","Fuel Tank","Fuel Injector","Fuel Pressure Regulator","Fuel Rail","Mass Air Flow Sensor","Oxygen Sensor (O2)","Throttle Position Sensor","MAP Sensor"],"Exhaust":["Catalytic Converter","Muffler","Resonator","Exhaust Pipe Section","Exhaust Manifold","Exhaust Heat Shield","DPF (Diesel Particulate Filter)"],"Body & Glass":["Hood","Front Bumper Cover","Rear Bumper Cover","Front Fender","Rear Quarter Panel","Door Shell (Front)","Door Shell (Rear)","Trunk Lid / Liftgate","Windshield","Rear Glass","Door Glass (Front)","Side View Mirror","Grille","Headlight Assembly","Tail Light Assembly","Radiator Core Support"],"Interior":["Dash Panel / Instrument Panel","Center Console","Front Seat (Driver)","Front Seat (Passenger)","Rear Seat","Seat Belt Assembly","Speedometer / Cluster","Infotainment / Touchscreen","Radio / Stereo","Steering Wheel","Air Bag Module","Door Panel (Front)","Door Panel (Rear)"],"Wheels & Tires":["Wheel / Rim (Steel)","Wheel / Rim (Alloy)","Spare Tire & Wheel","Tire","TPMS Sensor"]};
const PF_MM = {"Acura":["ILX","Integra","Legend","MDX","NSX","RDX","RL","RLX","RSX","TL","TLX","TSX","ZDX"],"Alfa Romeo":["4C","Giulia","Giulietta","GTV","MiTo","Spider","Stelvio","Tonale"],"AMC":["AMX","Concord","Eagle","Gremlin","Hornet","Javelin","Matador","Pacer","Rambler","Spirit"],"Audi":["A3","A4","A5","A6","A7","A8","Q3","Q5","Q7","Q8","R8","RS3","RS5","S3","S4","S5","S6","TT"],"BMW":["1 Series","2 Series","3 Series","4 Series","5 Series","6 Series","7 Series","8 Series","M2","M3","M4","M5","M8","X1","X2","X3","X4","X5","X6","X7","Z3","Z4"],"Buick":["Cascada","Century","Enclave","Encore","Encore GX","Envision","LaCrosse","LeSabre","Park Avenue","Regal","Rendezvous","Skylark","Verano"],"Cadillac":["ATS","CT4","CT5","CT6","CTS","DeVille","DTS","Eldorado","Escalade","Escalade ESV","SRX","STS","XT4","XT5","XT6","XLR","XTS"],"Chevrolet":["Astro","Avalanche","Blazer","Camaro","Colorado","Corvette","Cruze","Equinox","Express","HHR","Impala","Malibu","Monte Carlo","Silverado 1500","Silverado 2500HD","Silverado 3500HD","Sonic","Spark","Suburban","Tahoe","TrailBlazer","Traverse","Trax"],"Chrysler":["200","300","300M","Aspen","Concorde","Crossfire","LHS","Pacifica","PT Cruiser","Sebring","Town & Country","Voyager"],"Daewoo":["Gentra","Kalos","Lacetti","Lanos","Leganza","Matiz","Nubira"],"Dodge":["Avenger","Caliber","Challenger","Charger","Dakota","Dart","Durango","Grand Caravan","Journey","Magnum","Neon","Nitro","Stratus","Viper"],"Eagle":["Medallion","Premier","Summit","Talon","Vision"],"Fiat":["500","500 Abarth","500L","500X","Bravo","Panda","Punto","Tipo"],"Ford":["Bronco","Bronco Sport","C-Max","Crown Victoria","E-Series","EcoSport","Edge","Escape","Excursion","Expedition","Explorer","F-150","F-250","F-350","Fiesta","Flex","Focus","Fusion","Maverick","Mustang","Mustang Mach-E","Ranger","Taurus","Thunderbird","Transit","Windstar"],"Geo":["Metro","Prizm","Spectrum","Storm","Tracker"],"GMC":["Acadia","Canyon","Envoy","Jimmy","Safari","Sierra 1500","Sierra 2500HD","Sierra 3500HD","Sonoma","Terrain","Typhoon","Yukon","Yukon XL"],"Honda":["Accord","Civic","CR-V","CR-Z","Element","Fit","HR-V","Insight","Odyssey","Passport","Pilot","Ridgeline","S2000"],"Hummer":["H1","H1 Alpha","H2","H2 SUT","H3","H3 Alpha","H3T"],"Hyundai":["Accent","Azera","Elantra","Equus","Genesis","Genesis Coupe","Ioniq","Kona","Santa Cruz","Santa Fe","Sonata","Tiburon","Tucson","Veloster","Veracruz"],"Infiniti":["EX35","FX35","FX45","G25","G35","G37","I30","JX35","M35","M45","Q45","Q50","Q60","QX50","QX56","QX60","QX80"],"Isuzu":["Amigo","Ascender","Axiom","I-280","I-290","I-350","Rodeo","Trooper","VehiCROSS"],"Jaguar":["E-Pace","F-Pace","F-Type","I-Pace","S-Type","X-Type","XE","XF","XFR","XJ","XJ6","XJ8","XJR","XK","XKR"],"Jeep":["Cherokee","Commander","Compass","Gladiator","Grand Cherokee","Grand Wagoneer","Liberty","Patriot","Renegade","Wrangler","Wrangler Unlimited"],"Kia":["Amanti","Borrego","Cadenza","Forte","K5","K900","Niro","Optima","Rio","Sedona","Sorento","Soul","Sportage","Stinger","Telluride"],"Land Rover":["Defender","Discovery","Discovery Sport","Freelander","LR2","LR3","LR4","Range Rover","Range Rover Evoque","Range Rover Sport","Range Rover Velar"],"Lexus":["CT 200h","ES 300","ES 330","ES 350","GS 300","GS 350","GS 430","GX 460","GX 470","IS 250","IS 300","IS 350","IS-F","LC 500","LS 400","LS 430","LS 460","LS 500","LX 470","LX 570","NX 200t","NX 300","RX 300","RX 330","RX 350","RX 400h","SC 430"],"Lincoln":["Aviator","Continental","Corsair","Mark VII","Mark VIII","MKC","MKS","MKT","MKX","MKZ","Nautilus","Navigator","Navigator L","Town Car"],"Mazda":["CX-3","CX-30","CX-5","CX-7","CX-9","CX-50","Mazda2","Mazda3","Mazda5","Mazda6","MPV","MX-5 Miata","Protege","RX-7","RX-8","Tribute"],"Mercury":["Cougar","Grand Marquis","Mariner","Milan","Montego","Mountaineer","Mystique","Sable","Topaz","Tracer","Villager"],"Mercedes":["C230","C250","C300","C350","C43 AMG","C63 AMG","CLA 250","CLK 350","CLS 500","E 300","E 320","E 350","E 450","G 500","G 550","GLA 250","GLC 300","GLE 350","GLS 450","ML 320","ML 350","S 500","S 550","SL 500","SLK 300","SLK 350","Sprinter"],"MINI":["Clubman","Convertible","Cooper","Cooper D","Cooper S","Countryman","JCW","One","Paceman","Roadster"],"Mitsubishi":["3000GT","Diamante","Eclipse","Eclipse Cross","Galant","Lancer","Lancer Evolution","Mirage","Montero","Montero Sport","Outlander","Outlander Sport"],"Nissan":["350Z","370Z","Altima","Armada","Cube","Frontier","GT-R","Juke","Leaf","Maxima","Murano","Pathfinder","Quest","Rogue","Sentra","Titan","Titan XD","Xterra"],"Oldsmobile":["98","Achieva","Alero","Aurora","Bravada","Cutlass","Cutlass Supreme","Delta 88","Intrigue","Silhouette","Toronado"],"Plymouth":["Barracuda","Breeze","Duster","Fury","Grand Voyager","GTX","Neon","Prowler","Road Runner","Satellite","Valiant","Voyager"],"Pontiac":["Aztek","Bonneville","Fiero","Firebird","G5","G6","G8","Grand Am","Grand Prix","GTO","Montana","Solstice","Sunfire","Torrent","Trans Am","Vibe"],"Porsche":["718 Boxster","718 Cayman","911","914","918 Spyder","924","928","944","968","Boxster","Cayenne","Cayman","Macan","Panamera","Taycan"],"Ram":["1500","1500 Classic","1500 TRX","2500","3500","4500","Power Wagon","ProMaster","ProMaster City"],"Saturn":["Aura","Ion","L-Series","Outlook","Relay","SC","Sky","SL","SW","Vue"],"Scion":["FR-S","iA","iM","iQ","tC","xA","xB","xD"],"Subaru":["Ascent","BRZ","Crosstrek","Forester","Impreza","Legacy","Outback","Tribeca","WRX","WRX STI"],"Suzuki":["Aerio","Esteem","Forenza","Grand Vitara","Kizashi","Reno","Samurai","Sidekick","Swift","Verona","Vitara","X-90","XL-7"],"Tesla":["Cybertruck","Model 3","Model S","Model X","Model Y","Roadster"],"Toyota":["4Runner","Avalon","Camry","C-HR","Corolla","Corolla Cross","FJ Cruiser","GR86","Highlander","Land Cruiser","Matrix","Prius","Prius C","RAV4","Sequoia","Sienna","Supra","Tacoma","Tundra","Venza","Yaris"],"Volkswagen":["Atlas","Beetle","CC","EOS","Golf","Golf R","GTI","Jetta","Passat","Taos","Tiguan","Touareg"],"Volvo":["240","740","850","C30","C70","S40","S60","S70","S80","S90","V50","V60","V70","V90","XC40","XC60","XC70","XC90"]};
const PF_SY = {Acura:1986,"Alfa Romeo":1985,AMC:1966,Audi:1990,BMW:1988,Buick:1990,Cadillac:1985,Chevrolet:1985,Chrysler:1985,Daewoo:1999,Dodge:1985,Eagle:1988,Fiat:2011,Ford:1985,Geo:1989,GMC:1985,Honda:1985,Hummer:1992,Hyundai:1986,Infiniti:1990,Isuzu:1985,Jaguar:1990,Jeep:1985,Kia:1994,"Land Rover":1994,Lexus:1990,Lincoln:1985,Mazda:1985,Mercury:1985,Mercedes:1985,MINI:2002,Mitsubishi:1985,Nissan:1985,Oldsmobile:1985,Plymouth:1985,Pontiac:1985,Porsche:1985,Ram:2011,Saturn:1991,Scion:2004,Subaru:1985,Suzuki:1985,Tesla:2008,Toyota:1985,Volkswagen:1985,Volvo:1985};
const PF_EY = {AMC:1988,Daewoo:2002,Eagle:1998,Geo:1997,Hummer:2010,Mercury:2011,Oldsmobile:2004,Plymouth:2001,Pontiac:2010,Saturn:2010,Scion:2016,Suzuki:2012};
const PF_TOPTS = {"Ford/F-150":["2.7L EcoBoost","3.0L Diesel","3.3L V6","3.5L EcoBoost","5.0L V8","XL","XLT","Lariat","Platinum","King Ranch","Raptor","Limited"],"Ford/Mustang":["2.3L EcoBoost","3.7L V6","4.6L V8","5.0L V8 GT","5.2L GT350","5.8L GT500","GT","Mach 1"],"Ford/Explorer":["2.3L EcoBoost","3.0T ST","4.0L V6","4.6L V8","XLT","Limited","ST","Platinum"],"Chevrolet/Silverado 1500":["2.7T","4.3L V6","5.3L V8","6.2L V8","3.0L Duramax","WT","LS","LT","LTZ","High Country","Z71","Trail Boss"],"Chevrolet/Camaro":["2.0T","3.6L V6","6.2L V8 SS","6.2L V8 ZL1","LT","SS","ZL1","1LE"],"Chevrolet/Corvette":["6.2L Stingray","6.2L Mid-Engine","5.7L LS1","Z06","ZR1","Grand Sport"],"Dodge/Challenger":["3.6L V6","5.7L HEMI","6.4L SRT","6.2L Hellcat","6.2L Demon","SXT","R/T","Scat Pack"],"Dodge/Charger":["3.6L V6","5.7L HEMI","6.4L SRT","6.2L Hellcat","SXT","R/T","Scat Pack","Daytona"],"BMW/3 Series":["320i","325i","328i","330i","335i","340i","M3","sDrive","xDrive"],"BMW/5 Series":["528i","530i","535i","540i","550i","M5","sDrive","xDrive"],"BMW/X3":["xDrive28i","xDrive30i","xDrive35i","M40i","sDrive30i"],"BMW/X5":["xDrive35i","xDrive40i","xDrive50i","M50i","M Competition"],"Honda/Accord":["1.5T","2.0T","2.4L","3.5L V6","Hybrid","LX","Sport","EX","EX-L","Touring"],"Honda/Civic":["1.5T","2.0L","Si","Type R","LX","Sport","EX","EX-L","Touring"],"Honda/CR-V":["1.5T","2.0L Hybrid","2.4L","AWD","FWD","LX","EX","EX-L","Touring"],"Toyota/Camry":["2.5L LE","2.5L SE","2.5L XLE","3.5L V6","2.5L Hybrid","TRD","XSE V6"],"Toyota/Tundra":["3.5T V6","4.6L V8","5.7L V8","SR","SR5","Limited","Platinum","TRD Pro"],"Toyota/RAV4":["2.5L FWD","2.5L AWD","2.5L Hybrid","2.5L Prime PHEV","LE","XLE","TRD","Adventure","Limited"],"Toyota/Tacoma":["2.7L 4-cyl","3.5L V6","2WD","4WD","SR","SR5","TRD Sport","TRD Off-Road","TRD Pro"],"Toyota/4Runner":["4.0L V6 4WD","4.0L V6 2WD","SR5","TRD Sport","TRD Off-Road","Limited","TRD Pro"],"Jeep/Wrangler":["2.0T","3.6L Pentastar","3.0L EcoDiesel","4xe Hybrid","Sport","Sahara","Rubicon","Unlimited"],"Jeep/Grand Cherokee":["3.6L V6","5.7L HEMI","6.4L SRT","6.2L Trackhawk","3.0L Diesel","4xe","Laredo","Limited","Overland","Summit"],"Ram/1500":["3.6L Pentastar","5.7L HEMI","6.4L HEMI","3.0L EcoDiesel","Tradesman","Laramie","Limited","Rebel","TRX"],"Ram/2500":["6.4L HEMI","6.7L Cummins","Tradesman","Big Horn","Laramie","Limited","Power Wagon"],"Porsche/911":["Carrera","Carrera 4","Carrera S","Carrera 4S","Turbo","Turbo S","GT3","GT2 RS"],"Porsche/Cayenne":["3.0T V6","2.9T V6 S","4.0T V8 Turbo","E-Hybrid","Base","S","GTS","Turbo"],"Nissan/Altima":["2.5L","3.5L V6","2.0T VC-Turbo","AWD","FWD","S","SV","SL","SR","Platinum"],"Tesla/Model 3":["Standard Range","Long Range","Performance","AWD","RWD"],"Tesla/Model Y":["Standard Range","Long Range","Performance","AWD"],"Tesla/Model S":["Long Range","Plaid","75D","100D","P100D"],"Mercedes/C300":["RWD","4MATIC AWD","Sedan","Coupe","Cabriolet"],"Mercedes/E 350":["RWD","4MATIC","Sedan","Coupe","Wagon"],"Mercedes/GLE 350":["GLE 350 4MATIC","GLE 450 4MATIC","GLE 53 AMG","GLE 63 AMG","Coupe"],"Subaru/WRX":["2.0T","2.4T","STI","Base","Premium","Limited","TR"],"Subaru/Outback":["2.5L","3.6R","2.5T XT","AWD","Base","Premium","Limited","Wilderness"],"Lexus/RX 350":["3.5L FWD","3.5L AWD","Hybrid 450h","Base","Luxury","F Sport"],"Volvo/XC90":["T5 FWD","T6 AWD","T8 Hybrid","B5 AWD","B6 AWD","Momentum","R-Design","Inscription"],"Kia/Telluride":["3.8L V6","LX","S","EX","SX","Nightsky","X-Line"],"Hyundai/Sonata":["2.0T","2.4L","1.6T","2.5L","Hybrid","N Line","SE","SEL","Limited"]};
const PF_DOPTS = ["Base / Standard","LE","SE","SL","LX","EX","Sport","Limited","Premium","AWD","4WD","2WD","FWD","Diesel","Hybrid","PHEV"];
const PF_MON = "'DM Mono',monospace";
const PF_CSS = `@keyframes pf-led{0%,100%{opacity:1;box-shadow:0 0 5px #fff,0 0 12px rgba(255,255,255,.38)}50%{opacity:.25;box-shadow:none}}@keyframes pf-tick{from{transform:translateX(0)}to{transform:translateX(-50%)}}@keyframes pf-up{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}`;
const pfBuildYears = m => Array.from({length:(PF_EY[m]||2025)-(PF_SY[m]||1990)+1},(_,i)=>(PF_EY[m]||2025)-i);
const PfDot = ({on,lg}) => <span style={{width:lg?7:5,height:lg?7:5,borderRadius:"50%",display:"inline-block",flexShrink:0,background:on?"#fff":"rgba(255,255,255,0.14)",boxShadow:on?"0 0 5px #fff,0 0 12px rgba(255,255,255,.36)":"none",animation:on?"pf-led 2.2s ease infinite":"none",transition:"all .25s"}}/>;
const PfLbl = ({n,t,on}) => <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:6}}><PfDot on={on}/><span style={{fontFamily:PF_MON,fontSize:9,fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(113,130,165,0.6)"}}>{n} — {t}</span></div>;
const pfSS = (on,dis) => ({width:"100%",padding:"10px 30px 10px 11px",background:on?"rgba(255,255,255,0.07)":"rgba(255,255,255,0.025)",border:"1px solid "+(on?"rgba(255,255,255,0.27)":"rgba(255,255,255,0.08)"),borderRadius:5,color:on?"#f0f2f8":"rgba(115,133,168,0.62)",fontFamily:PF_MON,fontSize:11,letterSpacing:"0.06em",cursor:dis?"not-allowed":"pointer",opacity:dis?0.36:1,appearance:"none",WebkitAppearance:"none",backgroundImage:"url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='5'%3E%3Cpath d='M0 0l4.5 5L9 0z' fill='%236b7280'/%3E%3C/svg%3E\")",backgroundRepeat:"no-repeat",backgroundPosition:"right 10px center",outline:"none",transition:"all .18s"});
function PartsFinder({ defaultMake="" }) {
  const [cat,setCat]=useState(""); const [part,setPart]=useState("");
  const [make,setMake]=useState(defaultMake); const [mod,setMod]=useState("");
  const [yr,setYr]=useState(""); const [opt,setOpt]=useState("");
  const [nm,setNm]=useState(""); const [ph,setPh]=useState("");
  const [em,setEm]=useState(""); const [view,setView]=useState("search");
  const [busy,setBusy]=useState(false);
  const hCat=v=>{setCat(v);setPart("");}; const hMake=v=>{setMake(v);setMod("");setYr("");setOpt("");};
  const hMod=v=>{setMod(v);setYr("");setOpt("");}; const hYr=v=>{setYr(v);setOpt("");};
  const parts=cat?(PF_CATS[cat]||[]):[];
  const mods=make?[...(PF_MM[make]||[])].sort():[];
  const years=make?pfBuildYears(make):[];
  const opts=(make&&mod)?(PF_TOPTS[make+"/"+mod]||PF_DOPTS):[];
  const ready=part&&make&&mod&&yr;
  const submit=async()=>{
    if(!nm||!ph||busy)return; setBusy(true);
    const summary=`${yr} ${make} ${mod}${opt?" · "+opt:""} — ${part}`;
    try{await fetch("https://formsubmit.co/ajax/auapworld@gmail.com",{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({name:nm,phone:ph,email:em,part,make,model:mod,year:yr,option:opt,summary,_subject:"AUAPW Quote: "+summary})});}catch(e){}
    setBusy(false);setView("sent");
  };
  const reset=()=>{setCat("");setPart("");setMake(defaultMake);setMod("");setYr("");setOpt("");setNm("");setPh("");setEm("");setView("search");};
  if(view==="sent") return (
    <section style={{padding:"48px 24px",background:"rgba(7,9,15,0.98)",borderTop:"1px solid rgba(255,255,255,0.07)"}}>
      <style>{PF_CSS}</style>
      <div style={{maxWidth:480,margin:"0 auto",textAlign:"center",animation:"pf-up .5s ease"}}>
        <div style={{width:56,height:56,borderRadius:"50%",border:"1px solid rgba(255,255,255,0.14)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px",fontSize:24}}>✓</div>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:"clamp(1.4rem,4vw,1.9rem)",fontWeight:900,marginBottom:8}}>Request Received!</div>
        <p style={{fontFamily:PF_MON,fontSize:11,color:"rgba(140,158,192,0.7)",lineHeight:1.85,marginBottom:20}}>
          <span style={{color:"rgba(198,214,248,0.88)"}}>{part}</span><br/>
          <span style={{color:"rgba(130,148,185,0.55)"}}>{yr} {make} {mod}{opt?" · "+opt:""}</span>
        </p>
        <p style={{fontFamily:PF_MON,fontSize:9,letterSpacing:"0.14em",textTransform:"uppercase",color:"rgba(108,126,160,0.5)",marginBottom:20}}>Our parts experts will call you within 24 hours</p>
        <div style={{display:"flex",gap:10,justifyContent:"center"}}>
          <a href="tel:8888185001" style={{padding:"10px 18px",background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.13)",borderRadius:5,fontFamily:PF_MON,fontSize:10,letterSpacing:"0.13em",color:"#f0f2f8",textDecoration:"none",textTransform:"uppercase"}}>📞 (888) 818-5001</a>
          <button onClick={reset} style={{padding:"10px 18px",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:5,fontFamily:PF_MON,fontSize:10,letterSpacing:"0.13em",color:"rgba(140,158,200,0.7)",cursor:"pointer",textTransform:"uppercase"}}>New Search</button>
        </div>
      </div>
    </section>
  );
  return (
    <section style={{padding:"48px 24px 56px",background:"rgba(7,9,15,0.98)",borderTop:"1px solid rgba(255,255,255,0.07)"}}>
      <style>{PF_CSS}</style>
      <div style={{maxWidth:780,margin:"0 auto"}}>
        <div style={{textAlign:"center",marginBottom:24}}>
          <div style={{display:"inline-flex",alignItems:"center",gap:7,marginBottom:10,padding:"5px 15px",background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:20}}>
            <PfDot on lg/><span style={{fontFamily:PF_MON,fontSize:9,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(130,150,190,0.52)"}}>Find Your Part — Fast & Free</span><PfDot on lg/>
          </div>
          <h2 style={{fontFamily:"'Syne',sans-serif",fontSize:"clamp(1.4rem,3.5vw,2rem)",fontWeight:900,marginBottom:6}}>Parts Search</h2>
          <p style={{fontFamily:PF_MON,fontSize:10,color:"rgba(125,145,182,0.5)",letterSpacing:"0.08em"}}>46 Makes · 638 Models · 144 Parts · Free Shipping · 6-Month Warranty</p>
        </div>
        <div style={{background:"rgba(8,11,20,0.97)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:11,overflow:"hidden",boxShadow:"0 20px 56px rgba(0,0,0,0.5)"}}>
          <div style={{height:2,background:"linear-gradient(90deg,transparent,rgba(255,255,255,0.36),rgba(255,255,255,0.62),rgba(255,255,255,0.36),transparent)"}}/>
          <div style={{overflow:"hidden",borderBottom:"1px solid rgba(255,255,255,0.05)",padding:"7px 0",background:"rgba(255,255,255,0.012)"}}>
            <div style={{display:"flex",animation:"pf-tick 28s linear infinite",whiteSpace:"nowrap"}}>
              {[0,1].map(x=><span key={x} style={{fontFamily:PF_MON,fontSize:9,letterSpacing:"0.15em",color:"rgba(113,130,165,0.34)",textTransform:"uppercase",paddingRight:44}}>FREE SHIPPING ALL 50 STATES · ENGINES · TRANSMISSIONS · SUSPENSION · BODY PARTS · ELECTRICAL · 6-MONTH WARRANTY · 2,000+ VERIFIED YARDS · (888) 818-5001 ·&nbsp;</span>)}
            </div>
          </div>
          <div style={{padding:"clamp(16px,3.5vw,28px)"}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:18}}>
              <PfDot on lg/>
              <span style={{fontFamily:"'Syne',sans-serif",fontSize:"clamp(.9rem,2.2vw,1.1rem)",fontWeight:900}}>Find Your Part</span>
              {make&&<span style={{fontFamily:PF_MON,fontSize:9,color:"rgba(113,130,165,0.4)",letterSpacing:"0.13em",textTransform:"uppercase",marginLeft:4}}>— {make}</span>}
              <span style={{marginLeft:"auto",fontFamily:PF_MON,fontSize:9,color:"rgba(113,130,165,0.36)",letterSpacing:"0.11em",textTransform:"uppercase"}}>6-Mo Warranty · Free Ship</span>
            </div>
            {view==="search"&&(
              <div style={{animation:"pf-up .25s ease"}}>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(205px,1fr))",gap:11}}>
                  <div><PfLbl n="1" t="Part Category" on={!!cat}/>
                    <select style={pfSS(!!cat,false)} value={cat} onChange={e=>hCat(e.target.value)}>
                      <option value="">— Select Category —</option>
                      {Object.keys(PF_CATS).map(c=><option key={c} value={c}>{c}</option>)}
                    </select></div>
                  <div><PfLbl n="2" t="Select Part" on={!!part}/>
                    <select style={pfSS(!!part,!cat)} value={part} onChange={e=>setPart(e.target.value)} disabled={!cat}>
                      <option value="">{cat?"— Select Part —":"— Category first —"}</option>
                      {parts.map(p=><option key={p} value={p}>{p}</option>)}
                    </select></div>
                  <div><PfLbl n="3" t="Select Make" on={!!make}/>
                    <select style={pfSS(!!make,!part)} value={make} onChange={e=>hMake(e.target.value)} disabled={!part}>
                      <option value="">{part?"— Select Make —":"— Part first —"}</option>
                      {Object.keys(PF_MM).sort().map(m=><option key={m} value={m}>{m}</option>)}
                    </select></div>
                  <div><PfLbl n="4" t="Select Model" on={!!mod}/>
                    <select style={pfSS(!!mod,!make)} value={mod} onChange={e=>hMod(e.target.value)} disabled={!make}>
                      <option value="">{make?"— Select Model —":"— Make first —"}</option>
                      {mods.map(m=><option key={m} value={m}>{m}</option>)}
                    </select></div>
                  <div><PfLbl n="5" t="Select Year" on={!!yr}/>
                    <select style={pfSS(!!yr,!mod)} value={yr} onChange={e=>hYr(e.target.value)} disabled={!mod}>
                      <option value="">{mod?"— Select Year —":"— Model first —"}</option>
                      {years.map(y=><option key={y} value={y}>{y}</option>)}
                    </select></div>
                  <div><PfLbl n="6" t="Option / Trim" on={!!opt}/>
                    <select style={pfSS(!!opt,!yr)} value={opt} onChange={e=>setOpt(e.target.value)} disabled={!yr}>
                      <option value="">{yr?"— Select Option —":"— Year first —"}</option>
                      {opts.map(o=><option key={o} value={o}>{o}</option>)}
                    </select></div>
                </div>
                {ready&&(
                  <div style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.09)",borderRadius:6,padding:"12px 14px",marginTop:14,display:"flex",gap:8,alignItems:"flex-start",animation:"pf-up .3s ease"}}>
                    <PfDot on/>
                    <div style={{fontFamily:PF_MON,fontSize:11,color:"rgba(193,210,246,0.86)",lineHeight:1.75}}>
                      <span style={{color:"rgba(113,130,165,0.48)"}}>Part: </span>{part}<br/>
                      <span style={{color:"rgba(113,130,165,0.48)"}}>Vehicle: </span>{yr} {make} {mod}{opt?" · "+opt:""}
                    </div>
                  </div>
                )}
                <div style={{display:"flex",gap:10,marginTop:14,flexWrap:"wrap"}}>
                  <button onClick={()=>ready&&setView("form")} style={{flex:1,minWidth:155,padding:"12px 16px",borderRadius:5,background:ready?"rgba(255,255,255,0.09)":"rgba(255,255,255,0.025)",border:"1px solid "+(ready?"rgba(255,255,255,0.28)":"rgba(255,255,255,0.07)"),fontFamily:PF_MON,fontSize:11,fontWeight:700,letterSpacing:"0.17em",textTransform:"uppercase",color:ready?"#f0f2f8":"rgba(106,124,160,0.36)",cursor:ready?"pointer":"not-allowed",transition:"all .2s"}}>
                    {ready?"Get Free Quote →":"Complete All Fields"}
                  </button>
                  <a href="tel:8888185001" style={{display:"flex",alignItems:"center",gap:5,padding:"12px 14px",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:5,fontFamily:PF_MON,fontSize:10,letterSpacing:"0.11em",textTransform:"uppercase",color:"rgba(135,155,198,0.6)",textDecoration:"none",whiteSpace:"nowrap"}}>📞 (888) 818-5001</a>
                </div>
              </div>
            )}
            {view==="form"&&(
              <div style={{animation:"pf-up .25s ease"}}>
                <button onClick={()=>setView("search")} style={{background:"none",border:"none",fontFamily:PF_MON,fontSize:9,letterSpacing:"0.17em",textTransform:"uppercase",color:"rgba(113,130,165,0.48)",cursor:"pointer",marginBottom:16,padding:0,display:"flex",alignItems:"center",gap:5}}>← Back to Search</button>
                <div style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:6,padding:"13px 15px",marginBottom:18}}>
                  <div style={{fontFamily:PF_MON,fontSize:8,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(106,124,160,0.48)",marginBottom:6}}>Part Request Summary</div>
                  <div style={{fontFamily:PF_MON,fontSize:11,color:"rgba(192,210,246,0.87)",lineHeight:1.78}}>
                    <span style={{color:"rgba(106,124,160,0.44)"}}>Part: </span>{part}<br/>
                    <span style={{color:"rgba(106,124,160,0.44)"}}>Vehicle: </span>{yr} {make} {mod}{opt?" · "+opt:""}
                  </div>
                </div>
                {[["Your Name",nm,setNm,"Full name","text",true],["Phone Number",ph,setPh,"(555) 000-0000","tel",true],["Email Address",em,setEm,"Optional","email",false]].map(([l,v,s,p,t,req])=>(
                  <div key={l} style={{marginBottom:13}}>
                    <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:5}}><PfDot on={!!v}/><span style={{fontFamily:PF_MON,fontSize:9,fontWeight:700,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(106,124,160,0.58)"}}>{l}{req&&<span style={{color:"rgba(255,75,75,0.52)",marginLeft:3}}>*</span>}</span></div>
                    <input value={v} onChange={e=>s(e.target.value)} placeholder={p} type={t} style={{width:"100%",padding:"10px 12px",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:5,color:"#f0f2f8",fontFamily:PF_MON,fontSize:11,letterSpacing:"0.06em",outline:"none",transition:"border-color .18s"}} onFocus={e=>e.target.style.borderColor="rgba(255,255,255,0.25)"} onBlur={e=>e.target.style.borderColor="rgba(255,255,255,0.1)"}/>
                  </div>
                ))}
                <button onClick={submit} disabled={!nm||!ph||busy} style={{width:"100%",marginTop:5,padding:"13px 18px",borderRadius:5,background:(!nm||!ph)?"rgba(255,255,255,0.025)":"rgba(255,255,255,0.09)",border:"1px solid "+((!nm||!ph)?"rgba(255,255,255,0.07)":"rgba(255,255,255,0.27)"),fontFamily:PF_MON,fontSize:11,fontWeight:700,letterSpacing:"0.17em",textTransform:"uppercase",color:(!nm||!ph)?"rgba(106,124,160,0.3)":"#f0f2f8",cursor:(!nm||!ph)?"not-allowed":"pointer",transition:"all .2s"}}>
                  {busy?"Sending…":"Submit Quote Request →"}
                </button>
                <p style={{textAlign:"center",fontFamily:PF_MON,fontSize:8,color:"rgba(96,114,150,0.36)",marginTop:11,letterSpacing:"0.1em"}}>SECURE · NO SPAM · WE CALL WITHIN 24 HOURS</p>
              </div>
            )}
          </div>
          <div style={{borderTop:"1px solid rgba(255,255,255,0.05)",background:"rgba(255,255,255,0.011)",padding:"10px 18px",display:"flex",justifyContent:"space-around",flexWrap:"wrap",gap:8}}>
            {[["🔒","Secure"],["🚚","Free Ship"],["🛡️","6-Mo Warranty"],["⚡","24hr Response"],["🏆","2,000+ Yards"]].map(([ic,t])=>(
              <div key={t} style={{display:"flex",alignItems:"center",gap:5}}>
                <span style={{fontSize:12}}>{ic}</span>
                <span style={{fontFamily:PF_MON,fontSize:8,fontWeight:700,letterSpacing:"0.14em",textTransform:"uppercase",color:"rgba(125,145,188,0.42)"}}>{t}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
// ═══════════════════════════════════════════════════

function DiamondLed({ sm=false }) { return <div className={sm?"diamond-led-sm":"diamond-led"}/>; }
function Pulse() { return <div style={{width:6,height:6,borderRadius:"50%",background:"#fff",boxShadow:"0 0 6px #fff,0 0 14px rgba(255,255,255,0.5)",animation:"pulse-dot 2s ease infinite",flexShrink:0}}/>; }

function AuapwLogo({ size=88, uid="a" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" style={{flexShrink:0,display:"block"}}>
      <defs>
        <linearGradient id={`ch-${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#f0f4ff"/><stop offset="10%" stopColor="#ffffff"/>
          <stop offset="30%" stopColor="#d8dce8"/><stop offset="55%" stopColor="#8890a8"/>
          <stop offset="78%" stopColor="#b0b8cc"/><stop offset="100%" stopColor="#d0d4e4"/>
        </linearGradient>
        <linearGradient id={`tx-${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#ffffff"/><stop offset="20%" stopColor="#f0f2fc"/>
          <stop offset="45%" stopColor="#b0b8d0"/><stop offset="72%" stopColor="#606878"/>
          <stop offset="100%" stopColor="#c0c8dc"/>
        </linearGradient>
        <filter id={`gw-${uid}`} x="-15%" y="-15%" width="130%" height="130%">
          <feGaussianBlur stdDeviation="1.4" result="b"/>
          <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <clipPath id={`cp-${uid}`}><circle cx="100" cy="100" r="74"/></clipPath>
      </defs>
      <circle cx="100" cy="100" r="100" fill="#07090d"/>
      <path d={GEAR_PATH} fill={`url(#ch-${uid})`}/>
      <circle cx="100" cy="100" r="76" fill="none" stroke={`url(#ch-${uid})`} strokeWidth="2.5"/>
      <circle cx="100" cy="100" r="71" fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="0.9"/>
      <g clipPath={`url(#cp-${uid})`} fill="none" stroke={`url(#ch-${uid})`} strokeLinecap="round" strokeLinejoin="round">
        <rect x="65" y="67" width="35" height="22" rx="3" fill="rgba(200,215,235,0.1)" strokeWidth="1.9"/>
        <rect x="70" y="53" width="10" height="16" rx="2" fill="rgba(200,215,235,0.07)" strokeWidth="1.5"/>
        <rect x="85" y="53" width="10" height="16" rx="2" fill="rgba(200,215,235,0.07)" strokeWidth="1.5"/>
        <rect x="75" y="46" width="15" height="9" rx="2" fill="rgba(200,215,235,0.1)" strokeWidth="1.4"/>
        <circle cx="117" cy="70" r="16" fill="rgba(200,215,235,0.05)" strokeWidth="1.8"/>
        <circle cx="117" cy="70" r="8" fill="rgba(200,215,235,0.08)" strokeWidth="1.4"/>
        <line x1="117" y1="54" x2="117" y2="62" strokeWidth="1.4"/>
        <line x1="117" y1="78" x2="117" y2="86" strokeWidth="1.4"/>
        <line x1="101" y1="70" x2="109" y2="70" strokeWidth="1.4"/>
        <line x1="125" y1="70" x2="133" y2="70" strokeWidth="1.4"/>
        <line x1="100" y1="76" x2="101" y2="70" strokeWidth="2"/>
      </g>
      <text x="100" y="152" textAnchor="middle" fontFamily="'Arial Black',Impact,sans-serif" fontWeight="900" fontSize="64" letterSpacing="1" fill="rgba(0,0,0,0.95)" dx="2" dy="2.5">AUAPW</text>
      <text x="100" y="152" textAnchor="middle" fontFamily="'Arial Black',Impact,sans-serif" fontWeight="900" fontSize="64" letterSpacing="1" fill={`url(#tx-${uid})`} filter={`url(#gw-${uid})`}>AUAPW</text>
      <text x="100" y="152" textAnchor="middle" fontFamily="'Arial Black',Impact,sans-serif" fontWeight="900" fontSize="64" letterSpacing="1" fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth="0.7">AUAPW</text>
    </svg>
  );
}

function CornerLogo({ pos, delay=0 }) {
  const st = {position:"absolute",zIndex:10,...(pos.t!==undefined?{top:pos.t}:{bottom:pos.b}),...(pos.l!==undefined?{left:pos.l}:{right:pos.r})};
  return (
    <div style={st}>
      <div style={{position:"relative",width:28,height:28}}>
        <div style={{position:"absolute",inset:-4,borderRadius:"50%",border:"1px solid rgba(255,255,255,0.2)",animation:"led-pulse 2.5s ease-in-out infinite"}}/>
        <div style={{width:28,height:28,borderRadius:"50%",background:"radial-gradient(circle at 40% 35%,#1e2233,#0c0e18)",border:"1px solid rgba(255,255,255,0.25)",boxShadow:"0 0 10px rgba(255,255,255,0.2)",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",animation:"led-pulse 2.5s ease-in-out infinite"}}>
          <AuapwLogo size={24} uid={`cl-${delay}`}/>
        </div>
      </div>
    </div>
  );
}

function SiteHeader({ subtitle }) {
  const uid = "hdr";
  return (
    <div style={{position:"relative",overflow:"hidden",background:"linear-gradient(180deg,#060810 0%,#0a0c15 50%,#060810 100%)",borderTop:"1px solid rgba(255,255,255,0.06)",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
      <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:"linear-gradient(90deg,transparent 0%,rgba(255,255,255,0.08) 20%,rgba(255,255,255,0.55) 50%,rgba(255,255,255,0.08) 80%,transparent 100%)",boxShadow:"0 0 18px rgba(255,255,255,0.18)",zIndex:5}}/>
      <div style={{position:"absolute",bottom:0,left:0,right:0,height:1,background:"linear-gradient(90deg,transparent 0%,rgba(255,255,255,0.06) 25%,rgba(255,255,255,0.25) 50%,rgba(255,255,255,0.06) 75%,transparent 100%)",zIndex:5}}/>
      <div style={{position:"absolute",inset:0,backgroundImage:"radial-gradient(circle,rgba(255,255,255,0.018) 1px,transparent 1px)",backgroundSize:"24px 24px",pointerEvents:"none",zIndex:0}}/>
      <div style={{position:"absolute",right:"-1%",top:"50%",transform:"translateY(-50%)",opacity:0.028,pointerEvents:"none",zIndex:0}}>
        <AuapwLogo size={180} uid="wm"/>
      </div>
      <div style={{maxWidth:1400,margin:"0 auto",padding:"clamp(14px,2.2vw,22px) clamp(16px,3vw,40px)",display:"grid",gridTemplateColumns:"auto 1fr auto",alignItems:"center",gap:"clamp(16px,2.5vw,36px)",position:"relative",zIndex:4}}>
        {/* LEFT */}
        <div style={{display:"flex",alignItems:"center",gap:"clamp(12px,2vw,22px)",flexShrink:0}}>
          <div style={{display:"flex",alignItems:"flex-start",gap:"clamp(8px,1.2vw,14px)"}}>
            <div style={{position:"relative",flexShrink:0,marginTop:2}}>
              <div style={{position:"absolute",inset:-4,borderRadius:"50%",border:"1px solid rgba(255,255,255,0.15)",boxShadow:"0 0 10px rgba(255,255,255,0.08)"}}/>
              <div style={{width:"clamp(44px,6vw,62px)",height:"clamp(44px,6vw,62px)",borderRadius:"50%",background:"radial-gradient(circle at 38% 33%,#1e2233,#0c0e18 58%,#07090e)",border:"1.5px solid rgba(255,255,255,0.22)",boxShadow:"0 0 0 1px rgba(255,255,255,0.05),0 0 24px rgba(255,255,255,0.12),inset 0 1px 0 rgba(255,255,255,0.1)",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden"}}>
                <AuapwLogo size={54} uid="hdr-l"/>
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:"clamp(4px,0.6vw,6px)"}}>
              <div style={{position:"relative",display:"inline-block"}}>
                <div style={{position:"absolute",top:4,left:3,fontFamily:T.mono,fontWeight:900,fontSize:"clamp(1.4rem,3.2vw,2.1rem)",letterSpacing:"0.04em",lineHeight:1,color:"rgba(0,0,0,1)",pointerEvents:"none",zIndex:1,filter:"blur(6px)"}}>AUAPW.ORG</div>
                <div style={{position:"absolute",top:2,left:2,fontFamily:T.mono,fontWeight:900,fontSize:"clamp(1.4rem,3.2vw,2.1rem)",letterSpacing:"0.04em",lineHeight:1,color:"rgba(10,14,32,0.85)",pointerEvents:"none",zIndex:2,filter:"blur(1.8px)"}}>AUAPW.ORG</div>
                <div style={{position:"absolute",top:1,left:1,fontFamily:T.mono,fontWeight:900,fontSize:"clamp(1.4rem,3.2vw,2.1rem)",letterSpacing:"0.04em",lineHeight:1,color:"rgba(35,48,85,0.6)",pointerEvents:"none",zIndex:3}}>AUAPW.ORG</div>
                <div style={{position:"absolute",top:-1,left:-1,fontFamily:T.mono,fontWeight:900,fontSize:"clamp(1.4rem,3.2vw,2.1rem)",letterSpacing:"0.04em",lineHeight:1,color:"rgba(255,255,255,0.4)",pointerEvents:"none",zIndex:4,filter:"blur(0.7px)"}}>AUAPW.ORG</div>
                <div className="auapw-emboss" style={{fontSize:"clamp(1.4rem,3.2vw,2.1rem)",position:"relative",zIndex:5,textShadow:"0px -1px 0 rgba(255,255,255,0.85),-1px -1px 0 rgba(255,255,255,0.55),1px 1px 0 rgba(0,0,0,0.95),2px 2px 0 rgba(0,0,0,0.82),3px 3px 0 rgba(0,0,0,0.65),4px 4px 0 rgba(0,0,0,0.45),5px 5px 8px rgba(0,0,0,0.6)"}}>AUAPW.ORG</div>
                <div style={{position:"absolute",top:"-5%",left:"-130%",width:"38%",height:"110%",background:"linear-gradient(110deg,transparent,rgba(255,255,255,0.45),transparent)",animation:"ghost-scan 4s ease-in-out infinite 2s",pointerEvents:"none",zIndex:6}}/>
              </div>
              <div style={{display:"flex",alignItems:"center",gap:6}}><DiamondLed sm/><div className="sub-emboss" style={{fontSize:"clamp(0.55rem,1.1vw,0.68rem)",letterSpacing:"0.22em",whiteSpace:"nowrap"}}>ALL USED AUTO PARTS WAREHOUSE</div></div>
              <div style={{display:"flex",alignItems:"center",gap:6}}><DiamondLed sm/><div className="tagline-silver" style={{fontSize:"clamp(0.5rem,1vw,0.62rem)",whiteSpace:"nowrap"}}>Your Trusted Partner for Automotive Services &amp; Solutions</div></div>
            </div>
          </div>
          <div style={{width:1,height:"clamp(44px,6.5vw,68px)",flexShrink:0,background:"linear-gradient(180deg,transparent,rgba(255,255,255,0.18),transparent)"}}/>
        </div>
        {/* CENTER */}
        <div style={{display:"flex",flexDirection:"column",gap:"clamp(4px,0.6vw,7px)",alignItems:"center",minWidth:0,overflow:"hidden"}}>
          <div style={{overflow:"hidden",width:"100%",display:"flex",alignItems:"center",height:"clamp(13px,2vw,17px)"}}>
            <div style={{display:"flex",gap:"clamp(10px,1.5vw,18px)",whiteSpace:"nowrap",animation:"scroll-ticker 20s linear infinite"}}>
              {Array(14).fill(null).map((_,i)=>(
                <span key={i} style={{display:"inline-flex",alignItems:"center",gap:"clamp(8px,1.2vw,14px)"}}>
                  <span style={{fontFamily:T.mono,fontWeight:900,fontSize:"clamp(0.5rem,1.1vw,0.65rem)",letterSpacing:"0.22em",background:"linear-gradient(90deg,#505868,#9098b0,#d8dff0,#fff,#d8dff0,#9098b0,#505868)",backgroundSize:"300% auto",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text",animation:"chrome-sweep 5s linear infinite",filter:"drop-shadow(0 -0.5px 0 rgba(255,255,255,0.4)) drop-shadow(1px 1px 0 rgba(0,0,0,0.8))"}}>AUAPW</span>
                  <DiamondLed sm/>
                </span>
              ))}
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:7}}><DiamondLed sm/><div className="tagline-silver" style={{fontSize:"clamp(0.44rem,1vw,0.58rem)",textAlign:"center",whiteSpace:"nowrap"}}>Your Trusted Partner for Automotive Services &amp; Solutions</div><DiamondLed sm/></div>
          {subtitle && (
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{width:"clamp(16px,2.5vw,32px)",height:1,background:"linear-gradient(90deg,transparent,rgba(255,255,255,0.18))"}}/>
              <div style={{fontSize:"clamp(6.5px,0.9vw,8px)",color:"rgba(120,138,168,0.48)",fontFamily:T.mono,letterSpacing:"0.18em",textTransform:"uppercase",whiteSpace:"nowrap"}}>{subtitle}</div>
              <div style={{width:"clamp(16px,2.5vw,32px)",height:1,background:"linear-gradient(270deg,transparent,rgba(255,255,255,0.18))"}}/>
            </div>
          )}
        </div>
        {/* RIGHT — trust badges */}
        <div style={{display:"flex",flexDirection:"column",gap:"clamp(5px,0.8vw,8px)",alignItems:"flex-start",flexShrink:0}}>
          {[{l:"6-Mo Warranty",sub:"All Parts"},{l:"24-Hr Response",sub:"Expert Team"},{l:"All 50 States",sub:"Free Shipping"}].map(({l,sub})=>(
            <div key={l} style={{display:"flex",alignItems:"center",gap:8}}>
              <DiamondLed sm/>
              <div>
                <div style={{fontSize:"clamp(7.5px,1vw,9px)",fontWeight:700,letterSpacing:"0.12em",textTransform:"uppercase",color:"rgba(200,212,232,0.72)",fontFamily:T.mono,lineHeight:1.2}}>{l}</div>
                <div style={{fontSize:"clamp(6.5px,0.85vw,8px)",color:"rgba(120,135,160,0.45)",fontFamily:T.mono,letterSpacing:"0.08em"}}>{sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const NAV_ITEMS = [
  {l:"Home",href:"/"},{l:"Engines",href:"/used-engines"},{l:"Transmissions",href:"/used-transmissions"},
  {l:"Truck Parts",href:"/truck-parts"},{l:"About",href:"/about"},{l:"Contact",href:"/contact"},
];
const TICKERS = ["2,000+ Verified Yards","Free Shipping All Parts","6-Month Warranty","24-Hr Response","50+ Car Brands","Ships Anywhere USA"];

function Navbar({ activePage="" }) {
  return (
    <nav style={{position:"sticky",top:0,zIndex:50}}>
      <div style={{height:30,background:"linear-gradient(90deg,rgba(12,14,22,0.97),rgba(18,21,32,0.99) 50%,rgba(12,14,22,0.97))",borderBottom:"1px solid rgba(255,255,255,0.06)",overflow:"hidden",position:"relative"}}>
        <div style={{position:"absolute",top:0,bottom:0,left:0,width:48,background:"linear-gradient(to right,rgba(12,14,22,0.97),transparent)",zIndex:2}}/>
        <div style={{position:"absolute",top:0,bottom:0,right:0,width:48,background:"linear-gradient(to left,rgba(12,14,22,0.97),transparent)",zIndex:2}}/>
        <div style={{display:"flex",animation:"scroll-ticker 26s linear infinite",height:"100%",alignItems:"center",gap:40}}>
          {[...TICKERS,...TICKERS].map((t,i)=>(
            <span key={i} style={{display:"flex",alignItems:"center",gap:8,fontSize:"0.6rem",fontWeight:800,letterSpacing:"0.18em",textTransform:"uppercase",color:"rgba(138,143,160,0.8)",fontFamily:T.mono,flexShrink:0}}>⚡ {t}</span>
          ))}
        </div>
      </div>
      <div style={{height:68,background:"rgba(10,12,18,0.5)",backdropFilter:"blur(28px)",borderBottom:"1px solid rgba(255,255,255,0.08)",position:"relative"}}>
        <div style={{position:"absolute",inset:0,background:"linear-gradient(135deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01) 50%,rgba(255,255,255,0.02))",borderTop:"1px solid rgba(255,255,255,0.12)",boxShadow:"inset 0 1px 0 rgba(255,255,255,0.08),0 8px 32px rgba(0,0,0,0.5)"}}/>
        <div style={{maxWidth:1280,margin:"0 auto",padding:"0 24px",display:"flex",alignItems:"center",height:"100%",justifyContent:"space-between",gap:20,position:"relative",zIndex:1}}>
          <a href="/" style={{display:"flex",alignItems:"center",gap:12,textDecoration:"none",flexShrink:0}}>
            <AuapwLogo size={40} uid="nav"/>
            <div>
              <div className="auapw-emboss" style={{fontSize:15,textShadow:"0px -1px 0 rgba(255,255,255,0.85),1px 1px 0 rgba(0,0,0,0.95),2px 2px 0 rgba(0,0,0,0.82),3px 3px 0 rgba(0,0,0,0.65),4px 4px 4px rgba(0,0,0,0.5)"}}>AUAPW.ORG</div>
              <div style={{fontSize:7,color:"rgba(138,143,160,0.6)",fontFamily:T.mono,letterSpacing:"0.1em",marginTop:1}}>ALL USED AUTO PARTS WAREHOUSE</div>
              <div style={{fontSize:6.5,color:"rgba(120,135,160,0.5)",fontFamily:T.mono,letterSpacing:"0.08em",marginTop:1,fontStyle:"italic"}}>Trusted Partner for Automotive Services &amp; Solutions</div>
            </div>
          </a>
          <div style={{display:"flex",gap:20,flex:1,justifyContent:"center",flexWrap:"wrap"}}>
            {NAV_ITEMS.map(({l,href})=>(
              <a key={l} href={href} style={{fontSize:11,fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:activePage===href?"#fff":"rgba(200,205,215,0.75)",fontFamily:T.sans,textDecoration:"none",transition:"color 0.2s",padding:"4px 0",borderBottom:activePage===href?"1px solid rgba(255,255,255,0.4)":"1px solid transparent"}}>{l}</a>
            ))}
          </div>
          <div style={{display:"flex",gap:10,alignItems:"center",flexShrink:0}}>
            <a href={`tel:${PHONE}`} style={{display:"flex",alignItems:"center",gap:6,fontSize:11,color:"rgba(200,205,215,0.65)",fontFamily:T.mono,textDecoration:"none"}}>📞 {PHONE}</a>
            <a href="/contact" className="btn-led" style={{padding:"8px 16px",fontSize:9}}>Get Free Quote</a>
          </div>
        </div>
      </div>
    </nav>
  );
}

function SiteFooter() {
  const footerLinks = [
    {h:"Used Parts",items:[{l:"Used Engines",href:"/used-engines"},{l:"Transmissions",href:"/used-transmissions"},{l:"Truck Parts",href:"/truck-parts"}]},
    {h:"Company",items:[{l:"About Us",href:"/about"},{l:"Contact",href:"/contact"},{l:"Get a Quote",href:"/contact"}]},
    {h:"Legal",items:[{l:"Privacy Policy",href:"/privacy-policy"},{l:"Terms & Conditions",href:"/terms"},{l:"Shipping Policy",href:"/shipping-policy"},{l:"Return Policy",href:"/return-policy"},{l:"Cookie Policy",href:"/cookie-policy"},{l:"Disclaimer",href:"/disclaimer"},{l:"Acceptable Use",href:"/acceptable-use"}]},
  ];
  return (
    <footer style={{background:"rgba(7,9,15,0.98)",borderTop:"1px solid rgba(255,255,255,0.06)",paddingTop:48,fontFamily:T.mono}}>
      <div style={{maxWidth:1280,margin:"0 auto",padding:"0 32px"}}>
        <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",gap:32,paddingBottom:32,borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
          <div>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
              <AuapwLogo size={44} uid="ft"/>
              <div>
                <div className="auapw-emboss" style={{fontSize:14,textShadow:"0px -1px 0 rgba(255,255,255,0.7),1px 1px 0 rgba(0,0,0,0.9),2px 2px 0 rgba(0,0,0,0.7),3px 3px 4px rgba(0,0,0,0.5)"}}>AUAPW.ORG</div>
                <div style={{display:"flex",alignItems:"center",gap:5,marginTop:5}}><DiamondLed sm/><div className="sub-emboss" style={{fontSize:"0.52rem",letterSpacing:"0.2em"}}>ALL USED AUTO PARTS WAREHOUSE</div></div>
                <div style={{display:"flex",alignItems:"center",gap:5,marginTop:4}}><DiamondLed sm/><div className="tagline-silver" style={{fontSize:"0.48rem"}}>Your Trusted Partner for Automotive Services &amp; Solutions</div></div>
              </div>
            </div>
            <p style={{fontSize:11,color:"#9ca3af",lineHeight:1.8,fontWeight:300,marginBottom:16,maxWidth:300}}>Connecting buyers with 2,000+ verified salvage yards nationwide. Quality used OEM parts with 6-month warranty and free shipping.</p>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {[{ic:"📞",val:PHONE,href:`tel:${PHONE}`},{ic:"✉",val:EMAIL,href:`mailto:${EMAIL}`},{ic:"📍",val:ADDRESS}].map(({ic,val,href})=>(
                <a key={val} href={href||"#"} className="fc-item" style={{textDecoration:"none"}}>
                  <div className="fc-icon">{ic}</div>
                  <span className="fc-text">{val}</span>
                </a>
              ))}
            </div>
          </div>
          {footerLinks.map(({h,items})=>(
            <div key={h}>
              <div className="fsec" style={{marginBottom:14}}>{h}</div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {items.map(({l,href})=>(
                  <a key={l} href={href} style={{fontSize:11,color:"#9ca3af",textDecoration:"none",transition:"color 0.2s",fontFamily:T.mono}}
                    onMouseEnter={e=>e.target.style.color="#e8e8e8"} onMouseLeave={e=>e.target.style.color="#9ca3af"}>{l}</a>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{padding:"16px 0",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
          <span style={{fontSize:9,color:"#4b5563",letterSpacing:"0.1em"}}>© {new Date().getFullYear()} AUAPW.ORG · ALL USED AUTO PARTS WAREHOUSE · Trusted Partner for Automotive Services &amp; Solutions</span>
          <span style={{fontSize:9,color:"#4b5563",letterSpacing:"0.08em"}}>{ADDRESS} · {PHONE}</span>
        </div>
      </div>
    </footer>
  );
}


export default function PlymouthPage() {
  const [open, setOpen] = useState(null);
  return (
    <>
      <style>{LAYOUT_CSS}</style>
      <div className="auapw">
        <SiteHeader subtitle="Plymouth Used Parts · Engines · Transmissions · USA" />
        <Navbar activePage="" />

        {/* HERO */}
        <div style={{position:"relative",overflow:"hidden",background:"linear-gradient(160deg,#030509 0%,#080a14 55%,#050709 100%)",borderBottom:"1px solid rgba(255,255,255,.06)",padding:"clamp(44px,7vw,72px) 24px"}}>
          <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:"linear-gradient(90deg,transparent,#8b1a1a88,#8b1a1a,transparent)",boxShadow:"0 0 20px #8b1a1a44"}}/>
          <div style={{position:"absolute",inset:0,backgroundImage:"radial-gradient(circle,rgba(255,255,255,.015) 1px,transparent 1px)",backgroundSize:"24px 24px",pointerEvents:"none"}}/>
          <CornerLogo pos={{t:16,l:16}} delay={0}/>
          <CornerLogo pos={{t:16,r:16}} delay={0.5}/>
          <CornerLogo pos={{b:16,l:16}} delay={1}/>
          <CornerLogo pos={{b:16,r:16}} delay={1.5}/>
          <div style={{maxWidth:1120,margin:"0 auto",position:"relative",zIndex:2}}>
            <div style={{fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:".14em",color:"rgba(125,142,172,.45)",textTransform:"uppercase",marginBottom:16}}>AUAPW.ORG › Makes › Plymouth</div>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
              <DiamondLed sm/><span style={{fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:".18em",color:"rgba(165,182,215,.5)",textTransform:"uppercase"}}>Used Auto Parts · USA · Est. 1928</span><DiamondLed sm/>
            </div>
            <h1 style={{fontFamily:"'Syne',sans-serif",fontSize:"clamp(2rem,6vw,4rem)",fontWeight:900,letterSpacing:"-.02em",marginBottom:8,background:"linear-gradient(135deg,#fff 0%,#c8d4f0 32%,#8898c8 66%,#fff 100%)",backgroundSize:"250% auto",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text",animation:"chrome-sweep 8s linear infinite"}}>Plymouth Used Parts</h1>
            <div style={{fontFamily:"'DM Mono',monospace",fontSize:11,letterSpacing:".16em",color:"rgba(145,162,195,.48)",textTransform:"uppercase",marginBottom:16}}>"Look at Plymouth"</div>
            <p style={{fontSize:15,color:"rgba(165,182,212,.82)",lineHeight:1.78,maxWidth:680,marginBottom:24}}>Plymouth was a Chrysler brand from 1928 until 2001. Plymouth produced the legendary Road Runner, Cuda, and Barracuda muscle cars — and pioneered the entire minivan segment with the Voyager in 1983.</p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
              <a href="/contact" className="btn-led">📞 Free Quote</a>
              <a href={`mailto:${EMAIL}`} className="btn-led">✉ Email Us</a>
            </div>
          </div>
        </div>

        <div className="wrap">
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))",gap:12,marginBottom:28}}>
            <div style={{background:"rgba(14,17,28,0.9)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:8,padding:"18px 10px",textAlign:"center"}}><div style={{fontFamily:"'Syne',sans-serif",fontWeight:900,fontSize:"1.75rem",color:"#8b1a1a"}}>1928</div><div style={{fontSize:10,fontFamily:"'DM Mono',monospace",letterSpacing:".14em",color:"rgba(145,162,190,.6)",textTransform:"uppercase",marginTop:3}}>Founded</div></div>
            <div style={{background:"rgba(14,17,28,0.9)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:8,padding:"18px 10px",textAlign:"center"}}><div style={{fontFamily:"'Syne',sans-serif",fontWeight:900,fontSize:"1.75rem",color:"#8b1a1a"}}>73</div><div style={{fontSize:10,fontFamily:"'DM Mono',monospace",letterSpacing:".14em",color:"rgba(145,162,190,.6)",textTransform:"uppercase",marginTop:3}}>Years of Production</div></div>
            <div style={{background:"rgba(14,17,28,0.9)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:8,padding:"18px 10px",textAlign:"center"}}><div style={{fontFamily:"'Syne',sans-serif",fontWeight:900,fontSize:"1.75rem",color:"#8b1a1a"}}>1M+</div><div style={{fontSize:10,fontFamily:"'DM Mono',monospace",letterSpacing:".14em",color:"rgba(145,162,190,.6)",textTransform:"uppercase",marginTop:3}}>Parts in Network</div></div>
            <div style={{background:"rgba(14,17,28,0.9)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:8,padding:"18px 10px",textAlign:"center"}}><div style={{fontFamily:"'Syne',sans-serif",fontWeight:900,fontSize:"1.75rem",color:"#8b1a1a"}}>Road Runner</div><div style={{fontSize:10,fontFamily:"'DM Mono',monospace",letterSpacing:".14em",color:"rgba(145,162,190,.6)",textTransform:"uppercase",marginTop:3}}>Muscle Car Legend</div></div>
          </div>

          <div className="card" style={{marginBottom:16}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
              <DiamondLed sm/><h2 style={{fontSize:"1.15rem",fontWeight:800}}>Most Requested Plymouth Parts</h2>
            </div>
            <div style={{display:"flex",flexWrap:"wrap"}}>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ 5.7L HEMI</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ 5.2L Magnum</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ 3.3L V6</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ 2.0L SOHC</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ A518 / 41TE Auto</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ Alternator</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ Water Pump</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ Radiator</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ CV Axles</span>
              <span style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontSize:11,fontFamily:"'DM Mono',monospace",color:"rgba(165,182,212,.8)",letterSpacing:".05em",margin:3}}>◆ Transfer Case</span>
            </div>
          </div>

          <div className="card" style={{marginBottom:16}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
              <DiamondLed sm/><h2 style={{fontSize:"1.15rem",fontWeight:800}}>Popular Plymouth Models</h2>
            </div>
            <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Road Runner</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Barracuda</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Cuda</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Voyager</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Grand Voyager</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Neon</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Breeze</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Prowler</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Fury</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Duster</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Satellite</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>Valiant</span>
              <span style={{padding:"5px 12px",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:4,fontFamily:"'DM Mono',monospace",fontSize:11,color:"rgba(185,202,230,.75)",letterSpacing:".05em"}}>GTX</span>
            </div>
          </div>

          <div className="div-line"/>

          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:16}}>
            <DiamondLed sm/><h2 style={{fontSize:"clamp(1.25rem,3vw,1.75rem)",fontWeight:800}}>Plymouth History &amp; Heritage</h2>
          </div>
          <div style={{marginBottom:24}}>
            <div key={0} style={{display:"flex",gap:16,paddingBottom:22,borderLeft:"1px solid rgba(255,255,255,.07)",marginLeft:5,paddingLeft:22,position:"relative"}}><div style={{position:"absolute",left:-5,top:4,width:10,height:10,borderRadius:"50%",background:"#8b1a1a",boxShadow:"0 0 8px rgba(255,255,255,0.3)"}}/>  <div><div style={{fontFamily:"'DM Mono',monospace",fontSize:10,color:"rgba(175,195,230,.5)",letterSpacing:".1em",marginBottom:4}}>1928</div><div style={{fontSize:14,color:"rgba(198,212,238,.83)",lineHeight:1.67}}>Chrysler introduces Plymouth as a low-priced competitor to Ford and Chevrolet.</div></div></div>
            <div key={1} style={{display:"flex",gap:16,paddingBottom:22,borderLeft:"1px solid rgba(255,255,255,.07)",marginLeft:5,paddingLeft:22,position:"relative"}}><div style={{position:"absolute",left:-5,top:4,width:10,height:10,borderRadius:"50%",background:"#8b1a1a",boxShadow:"0 0 8px rgba(255,255,255,0.3)"}}/>  <div><div style={{fontFamily:"'DM Mono',monospace",fontSize:10,color:"rgba(175,195,230,.5)",letterSpacing:".1em",marginBottom:4}}>1964</div><div style={{fontSize:14,color:"rgba(198,212,238,.83)",lineHeight:1.67}}>The Plymouth Barracuda debuts two weeks before the Ford Mustang.</div></div></div>
            <div key={2} style={{display:"flex",gap:16,paddingBottom:22,borderLeft:"1px solid rgba(255,255,255,.07)",marginLeft:5,paddingLeft:22,position:"relative"}}><div style={{position:"absolute",left:-5,top:4,width:10,height:10,borderRadius:"50%",background:"#8b1a1a",boxShadow:"0 0 8px rgba(255,255,255,0.3)"}}/>  <div><div style={{fontFamily:"'DM Mono',monospace",fontSize:10,color:"rgba(175,195,230,.5)",letterSpacing:".1em",marginBottom:4}}>1968</div><div style={{fontSize:14,color:"rgba(198,212,238,.83)",lineHeight:1.67}}>The legendary Road Runner debuts — stripped-down, affordable, iconic.</div></div></div>
            <div key={3} style={{display:"flex",gap:16,paddingBottom:22,borderLeft:"1px solid rgba(255,255,255,.07)",marginLeft:5,paddingLeft:22,position:"relative"}}><div style={{position:"absolute",left:-5,top:4,width:10,height:10,borderRadius:"50%",background:"#8b1a1a",boxShadow:"0 0 8px rgba(255,255,255,0.3)"}}/>  <div><div style={{fontFamily:"'DM Mono',monospace",fontSize:10,color:"rgba(175,195,230,.5)",letterSpacing:".1em",marginBottom:4}}>1983</div><div style={{fontSize:14,color:"rgba(198,212,238,.83)",lineHeight:1.67}}>The Plymouth Voyager launches as one of the original minivans.</div></div></div>
            <div key={4} style={{display:"flex",gap:16,paddingBottom:22,borderLeft:"1px solid rgba(255,255,255,.07)",marginLeft:5,paddingLeft:22,position:"relative"}}><div style={{position:"absolute",left:-5,top:4,width:10,height:10,borderRadius:"50%",background:"#8b1a1a",boxShadow:"0 0 8px rgba(255,255,255,0.3)"}}/>  <div><div style={{fontFamily:"'DM Mono',monospace",fontSize:10,color:"rgba(175,195,230,.5)",letterSpacing:".1em",marginBottom:4}}>1999</div><div style={{fontSize:14,color:"rgba(198,212,238,.83)",lineHeight:1.67}}>The Prowler retro hot rod debuts to great fanfare.</div></div></div>
            <div key={5} style={{display:"flex",gap:16,paddingBottom:22,borderLeft:"1px solid rgba(255,255,255,.07)",marginLeft:5,paddingLeft:22,position:"relative"}}><div style={{position:"absolute",left:-5,top:4,width:10,height:10,borderRadius:"50%",background:"#8b1a1a",boxShadow:"0 0 8px rgba(255,255,255,0.3)"}}/>  <div><div style={{fontFamily:"'DM Mono',monospace",fontSize:10,color:"rgba(175,195,230,.5)",letterSpacing:".1em",marginBottom:4}}>2001</div><div style={{fontSize:14,color:"rgba(198,212,238,.83)",lineHeight:1.67}}>Chrysler discontinues Plymouth.</div></div></div>
          </div>

          <div className="div-line"/>

          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
            <DiamondLed sm/><h2 style={{fontSize:"clamp(1.25rem,3vw,1.75rem)",fontWeight:800}}>Plymouth Parts — FAQ</h2>
          </div>
          <div style={{fontSize:12,color:"rgba(145,162,192,.55)",letterSpacing:".1em",textTransform:"uppercase",marginBottom:20}}>Everything you need to know before you buy</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <div key={0} className="card" style={{cursor:"pointer"}} onClick={()=>setOpen(open===0?null:0)}><div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}><div className="fqq">Are Plymouth Voyager parts the same as Dodge Caravan?</div><div style={{fontFamily:"'DM Mono',monospace",fontSize:18,color:"rgba(165,182,215,.45)",flexShrink:0,lineHeight:1,marginTop:2}}>{open===0?"−":"+"}</div></div>{open===0 && <div className="fqa">Yes — the Plymouth Voyager and Dodge Grand Caravan share virtually all mechanical components.</div>}</div>
            <div key={1} className="card" style={{cursor:"pointer"}} onClick={()=>setOpen(open===1?null:1)}><div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}><div className="fqq">Do you carry classic Barracuda and Cuda parts?</div><div style={{fontFamily:"'DM Mono',monospace",fontSize:18,color:"rgba(165,182,215,.45)",flexShrink:0,lineHeight:1,marginTop:2}}>{open===1?"−":"+"}</div></div>{open===1 && <div className="fqa">Yes — 426 Hemi, 440 Six Pack, and 383 Magnum engines through our specialty Mopar network.</div>}</div>
            <div key={2} className="card" style={{cursor:"pointer"}} onClick={()=>setOpen(open===2?null:2)}><div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}><div className="fqq">How much does a used Plymouth Neon engine cost?</div><div style={{fontFamily:"'DM Mono',monospace",fontSize:18,color:"rgba(165,182,215,.45)",flexShrink:0,lineHeight:1,marginTop:2}}>{open===2?"−":"+"}</div></div>{open===2 && <div className="fqa">Used 2.0L SOHC Neon engines run $250-$600.</div>}</div>
            <div key={3} className="card" style={{cursor:"pointer"}} onClick={()=>setOpen(open===3?null:3)}><div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}><div className="fqq">Are Plymouth parts interchangeable with Dodge?</div><div style={{fontFamily:"'DM Mono',monospace",fontSize:18,color:"rgba(165,182,215,.45)",flexShrink:0,lineHeight:1,marginTop:2}}>{open===3?"−":"+"}</div></div>{open===3 && <div className="fqa">Yes — Plymouth shared platforms with Dodge and Chrysler throughout production.</div>}</div>
            <div key={4} className="card" style={{cursor:"pointer"}} onClick={()=>setOpen(open===4?null:4)}><div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}><div className="fqq">What warranty?</div><div style={{fontFamily:"'DM Mono',monospace",fontSize:18,color:"rgba(165,182,215,.45)",flexShrink:0,lineHeight:1,marginTop:2}}>{open===4?"−":"+"}</div></div>{open===4 && <div className="fqa">All AUAPW Plymouth parts carry a 6-month warranty.</div>}</div>
            <div key={5} className="card" style={{cursor:"pointer"}} onClick={()=>setOpen(open===5?null:5)}><div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}><div className="fqq">Which models have the most parts?</div><div style={{fontFamily:"'DM Mono',monospace",fontSize:18,color:"rgba(165,182,215,.45)",flexShrink:0,lineHeight:1,marginTop:2}}>{open===5?"−":"+"}</div></div>{open===5 && <div className="fqa">The Voyager/Grand Voyager and Neon have the highest availability.</div>}</div>
          </div>

          <div className="div-line"/>

          <div className="card" style={{textAlign:"center",padding:"38px 24px",background:"linear-gradient(135deg,rgba(12,15,26,.97),rgba(8,10,18,.98))"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginBottom:10}}>
              <DiamondLed sm/><span style={{fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:".18em",color:"rgba(145,162,192,.5)",textTransform:"uppercase"}}>Ready to Order?</span><DiamondLed sm/>
            </div>
            <h3 style={{fontSize:"clamp(1.2rem,3vw,1.65rem)",fontWeight:800,marginBottom:10}}>Find Your Plymouth Part Today</h3>
            <p style={{fontSize:14,color:"rgba(142,158,185,.68)",maxWidth:480,margin:"0 auto 22px",lineHeight:1.65}}>2,000+ verified yards · 6-month warranty · Free shipping all 50 states · 24-hour response</p>
            <div style={{display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap"}}>
              <a href={`tel:${PHONE}`} className="btn-led" style={{borderColor:"#8b1a1a88",background:"#8b1a1a18"}}>📞 {PHONE}</a>
              <a href={`mailto:${EMAIL}`} className="btn-led">✉ {EMAIL}</a>
            </div>
          </div>
        </div>

        <PartsFinder defaultMake="Plymouth"/>
        <SiteFooter />
      </div>
    </>
  );
}
